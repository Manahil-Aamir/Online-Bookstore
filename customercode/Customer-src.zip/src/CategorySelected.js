import React from 'react'

function CategorySelected() {
  return (
    <div>
      this  is category select 
    </div>
  )
}

export default CategorySelected
